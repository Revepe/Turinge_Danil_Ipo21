﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace propertisClass
{
    class Student//z1
    {
        public string Name { get; set; }
    }

    class Child//z2
    {
        public int Age { get; set; }
        public Child() { }
    }

    class Car//z3,4
    {
        private int year;//z3
        public int Year
        {
            get { return year; }
            set { if (value > 0) year = value; }
        }
        public string Name { get; set; }//z4
        public string Color { get; set; }
        public Car() { }
    }

    class Product//z5
    {
        protected string name;
        public string Name
        {
            get { return name; }
            private set { }
        }
        public Product() { name = "артур"; }
    }

    class Program
    {
        static void Main()
        {
            Student student = new Student();//z1
            student.Name = "даня";

            Child child = new Child { Age = 17 };//z2 

            Car car = new Car();//z3 
            car.Year = 2023;

            Car bmw = new Car//z4 
            {
                Name = "BMW",
                Color = "white"
            };

            Product product = new Product();//z5 
            Console.WriteLine(product.Name);
        }
    }
}
