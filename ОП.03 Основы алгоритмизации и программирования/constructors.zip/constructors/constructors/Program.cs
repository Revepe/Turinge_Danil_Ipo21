﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructors
{    
        class Student { public Student() { } } //z1

        class Child { public Child() { } }//z2

        class Car//z3-4
        {
            public int year;
            public string name;
            public string color;

            public Car(int year) { this.year = year; }//z3
            public Car(string name, string color) { this.name = name; this.color = color; }//z4
        }

        class Product//z5
        {
            protected string name;
            public Product(string name) { this.name = name; }
            public Product(Product other) { this.name = other.name; }
        }

        class Person//z6
        {
            private int age;
            public Person() { age = 17; }
            public void Print() { Console.WriteLine(age); }
        }

        class Manager//z7
        {
            private int age;
            private string name;
            public Manager(int age, string name) { this.age = age; this.name = name; }
            public Manager(Manager other) { this.age = other.age; this.name = other.name; }
        }

        class Program
        {
            static void Main()
            {
                Child child1 = new Child();//z2

                Car car = new Car(2007);//z3

                Car lada = new Car("Audi", "black");//z4
                Car bmw = new Car("Mersedes", "black");

                Product p1 = new Product("ПОтете");//z5
                Product p2 = new Product(p1);

                Person person = new Person();//z6
                person.Print();

                Manager manager1 = new Manager(20, "Чел1");//z7
                Manager manager2 = new Manager(18, "Чел2");
            }
        }
    }

