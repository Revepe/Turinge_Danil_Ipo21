﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nasled
{
    class Person { }//z1
    class Student : Person { }

    class Animal { }//z2
    class Cat : Animal { }
    class Dog : Animal { }

    class Entity { }//z3
    class Product : Entity { }

    class Dishes { }//z4
    class Cup : Dishes { }

    class Entity2 { }//z5
    class Staff : Entity2 { }
    class Manager : Staff { }

    class Animal2//z6
    {
        protected int age;
    }
    class Predator : Animal2
    {
        public void SetAge(int value) { age = value; }
        public int GetAge() { return age; }
    }

    class Transport//z7
    {
        protected string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
    class SpaceShuttle : Transport
    {
        public void DisplayInfo()
        {
            Console.WriteLine("вайб: " + name);
        }
    }

    class Program
    {
        static void Main()
        {
            Predator predator = new Predator();//z6
            predator.SetAge(5);
            Console.WriteLine(predator.GetAge());

            SpaceShuttle shuttle = new SpaceShuttle();//z7
            shuttle.Name = "вайб";
            shuttle.DisplayInfo();
        }
    }
}
