﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inca
{

    //z1
    class Student
    {
        public string name = "";

        public void Print()
        {
            Console.WriteLine($"Имя:{name}");

        }
    }

    //z2
    class Car
    {
        public int year = 11;
    }

    //z3
    class Point
    {
        public int x;
    }

    //z4
    class Person
    {
        public int age;
        public void Print()
        {
            Console.WriteLine($"Возраст:{age}");
        }

    }

    //z5
    class Table
    {
        public int rows;
        public int cols;

        public void Display()
        {
            Console.WriteLine($"Строчки:{rows}, Столбики:{cols}");
        }
    }

    //z6
    class Manager
    {
        public int age;
        public string name;

        public void GetAge()
        {
            Console.WriteLine($"Возраст: {age}");
        }

        public void GetName()
        {
            Console.WriteLine($"Имя: {name}");
        }
    }


    //z7
    class Point3D
    {
        public int x;
        public int y;
        public int z;

        public void Show()
        {
            Console.WriteLine($"Значение x: {x}, y: {y}, z: {z} ");
        }

    }



    //z8
    class Shop
    {
        public string name;
        public string newname;

        public void GetName()
        {
            Console.WriteLine($"Название магазина: {name}");
        }


        public void SetName()
        {
            Console.WriteLine($"Новое название магазина: {newname}");
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            //z1
            {
                Student p1 = new Student();
                p1.name = "Danya";
                p1.Print();
            }

            //z4
            {
                Person person1 = new Person();
                person1.age = 17;
                person1.Print();
            }


            //z5
            {
                Table table1 = new Table();
                table1.rows = 20;
                table1.cols = 40;
                table1.Display();
            }

            //z6
            {
                Manager manager1 = new Manager();
                manager1.age = 17;
                manager1.name = "Artur";
                manager1.GetName();
                manager1.GetAge();

            }

            //z7
            {
                Point3D point3D = new Point3D();
                point3D.x = 1;
                point3D.y = 2;
                point3D.z = 3;
                point3D.Show();
            }

            //z8
            {
                Shop shop = new Shop();
                shop.name = "val";
                shop.newname = "valbad";
                shop.GetName();
                shop.SetName();
            }


        }
    }
}