﻿using System;

namespace MyLibrary
{
    
    public static class BasicMath
    {
       
        public static double Add(double a, double b)
        {
            return a + b;
        }

        
        public static double Subtract(double a, double b)
        {
            return a - b;
        }

        
        public static double Multiply(double a, double b)
        {
            return a * b;
        }

        /// <summary>
        /// Деление двух чисел.
        /// </summary>
        /// <exception cref="ArgumentException">
        
        public static double Divide(double a, double b)
        {
            if (b == 0)
                throw new ArgumentException("Деление на ноль невозможно.");

            return a / b;
        }

      
        public static bool TryDivide(double a, double b, out double result)
        {
            if (b == 0)
            {
                result = 0;
                return false;
            }

            result = a / b;
            return true;
        }
    }
}
