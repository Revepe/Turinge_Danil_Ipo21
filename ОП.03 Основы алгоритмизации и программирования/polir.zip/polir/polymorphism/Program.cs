﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace polymorphism
{
    class Strategy//z1
    {
        public virtual void Display() => Console.WriteLine("Strategy");
    }

    class Weather//z2
    {
        public virtual void Show() => Console.WriteLine("My Weather");
    }

    class ConservativeStrategy : Strategy//z3
    {
        public override void Display() => Console.WriteLine("Conservative Strategy");
    }

    class Animal//z4
    {
        private string type;
        public Animal() { type = "My Type"; }
        public virtual void Print() => Console.WriteLine(type);
    }

    class Cat : Animal
    {
        private int age;
        public Cat() { age = 5; }
        public override void Print() => Console.WriteLine(age);
    }

    abstract class Entity//z5
    {
        public abstract void Display();
    }

    class Product : Entity//z6
    {
        public override void Display() => Console.WriteLine("My Product");
    }

    // z5.7
    interface IPrintable
    {
        void Display();
    }

    class ConsolePrinting : IPrintable
    {
        public void Display() => Console.WriteLine("My Console");
    }

    class Program
    {
        static void Main()
        {
            Weather weather = new Weather();//z2
            weather.Show();

            Strategy strategy = new ConservativeStrategy();//z3
            strategy.Display();

            Animal animal = new Animal();//z4
            Cat cat = new Cat();
            animal.Print();
            cat.Print();

            Product product = new Product();//z5
            product.Display();

            ConsolePrinting printer = new ConsolePrinting();//z7
            printer.Display();
        }
    }
}
